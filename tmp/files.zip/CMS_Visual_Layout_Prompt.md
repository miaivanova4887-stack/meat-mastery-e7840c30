# CMS Prompt: Visual App Layout Builder

## Overview
You are an expert at building a **Content Management System (CMS) for visual app layout creation**. This system enables non-technical users and developers to design, preview, and manage application layouts without writing code. The CMS should provide an intuitive interface for building responsive, customizable application interfaces.

---

## Core Requirements

### 1. **Visual Layout Builder**
Create an interactive drag-and-drop interface that allows users to:
- **Add Components**: Insert UI components (buttons, text, forms, images, cards, grids, etc.) from a library
- **Position & Resize**: Drag elements to reposition them on a canvas; resize using handles
- **Arrange Layers**: Manage component hierarchy with a layers panel (bring forward, send backward)
- **Group Elements**: Combine multiple components into reusable groups
- **Align & Distribute**: Snap-to-grid alignment, distribute spacing evenly, auto-align tools

### 2. **Component Library**
Provide a pre-built library with:
- **Basic Components**: Text, Button, Image, Divider, Spacer, Input Field, Label
- **Container Components**: Card, Panel, Modal/Dialog, Drawer, Tabs, Accordion
- **Data Display**: Table, List, Grid, Data Card, Badge, Tag, Tooltip
- **Form Components**: Text Input, Textarea, Select, Checkbox, Radio, Toggle, Date Picker
- **Navigation**: Menu Bar, Sidebar, Breadcrumb, Pagination, Tab Navigation
- **Media**: Image Carousel, Video Player, Gallery
- **Custom**: Allow users to create and save custom component variations

### 3. **Styling & Theming**
Enable non-developers to style layouts with:
- **Color Picker**: Intuitive color selection for text, backgrounds, borders, shadows
- **Typography Controls**: Font family, size, weight, line height, letter spacing
- **Spacing Controls**: Padding, margin, gap (with visual representation)
- **Border & Shadow**: Border radius, border style/width, box shadows with presets
- **Layout Properties**: Display (flex, grid, block), flex direction, justify/align, gap
- **Theme Management**: Save and apply global color schemes, create dark/light variants
- **CSS Variables**: Expose CSS custom properties for consistent theming across components

### 4. **Responsiveness**
Support mobile-first responsive design:
- **Breakpoint Editor**: Define custom breakpoints (mobile, tablet, desktop, etc.)
- **Responsive Preview**: Toggle between device sizes with live preview
- **Responsive Controls**: Show/hide elements at specific breakpoints; adjust layout per breakpoint
- **Fluid Spacing**: Proportional padding/margin that scales with viewport
- **Responsive Grid**: Define column counts per breakpoint

### 5. **Content Management**
Allow flexible content management:
- **Text Editor**: Rich text editing (bold, italic, links, lists) for text components
- **Image Management**: Upload, crop, resize images; manage asset library
- **Dynamic Data Binding**: Link components to data sources (preview with sample data)
- **Form Validation**: Add validation rules (required, email, pattern matching)
- **Localization**: Support multiple languages with key-value pairs

### 6. **Preview & Export**
Enable testing and integration:
- **Live Preview**: Real-time preview of changes in a separate panel
- **Interactive Preview**: Click buttons, fill forms, test interactions
- **Device Preview**: Simulate multiple screen sizes and orientations
- **Code Export**: Generate HTML/CSS/React code that can be used in projects
- **JSON Export**: Export layout as JSON for API-driven rendering
- **Template Export**: Save layouts as reusable templates
- **Website Export**: Generate production-ready websites (Next.js, React, Vue, Static HTML, Shopify themes)
- **Mobile App Export**: Generate iOS (Swift/SwiftUI) and Android (Kotlin/Jetpack Compose) native code
- **Cross-Platform Export**: React Native and Flutter for code sharing

### 7. **Asset Management**
Organize and manage project assets:
- **Image Library**: Upload, organize, and search images
- **Icon Library**: Built-in icon sets (SVG-based) with search
- **Font Management**: Add custom fonts or select from font services
- **Color Palette**: Define project color schemes and swatches
- **Component Presets**: Save component configurations as reusable styles/variants

### 8. **Collaboration Features** (Optional)
Support team workflows:
- **Project Management**: Create, organize, and share CMS projects
- **Versioning**: Save layout versions with change history
- **Comments & Annotations**: Comment on specific components or sections
- **Share & Permissions**: Share projects with read/edit/admin permissions
- **Real-time Collaboration**: Multiple users editing the same layout simultaneously (if applicable)

### 9. **User Interface Design**

#### Layout Structure:
```
┌─────────────────────────────────────────────────────┐
│  Header: Logo, Project Name, Undo/Redo, Settings   │
├──────────┬──────────────────────┬──────────────────┤
│Component │      Canvas          │   Properties     │
│ Library  │   (Drag & Drop)      │    Panel         │
│          │                      │                  │
│ Search   │   ↓ Live Preview     │  Styling Tools   │
│ Category │                      │  Layout Props    │
│ Sections │                      │  Interactions    │
├──────────┴──────────────────────┴──────────────────┤
│ Bottom Panel: Layers, History, Responsive Preview  │
└─────────────────────────────────────────────────────┘
```

#### Navigation:
- **Sidebar**: Quick access to component library, assets, pages/screens
- **Top Toolbar**: Common actions (save, export, preview, settings)
- **Right Properties Panel**: Context-sensitive controls for selected element
- **Bottom Status Bar**: Zoom level, grid toggle, responsive breakpoint selector

### 10. **Key Interactions**
- **Select Component**: Click to select; show bounding box and properties
- **Drag to Canvas**: Drag components from library to canvas
- **Resize**: Grab corner/edge handles to resize
- **Move**: Drag selected component to reposition
- **Context Menu**: Right-click for quick actions (duplicate, delete, group, etc.)
- **Keyboard Shortcuts**: Delete (Del), Duplicate (Ctrl+D), Undo (Ctrl+Z), etc.
- **Snap-to-Grid**: Magnetic alignment to invisible grid
- **Guides**: Visual guides when aligning with other elements

---

## Technical Specifications

### Frontend Stack (Recommended):
- **React** or **Vue.js** for the main interface
- **Canvas Library**: Use libraries like `React Flow`, `Excalidraw`, or custom canvas implementation
- **Styling**: Tailwind CSS, CSS-in-JS, or styled-components for the CMS UI itself
- **State Management**: Context API, Redux, or Zustand for managing layout state
- **Icons**: Lucide React or similar icon library
- **Drag & Drop**: React DnD, Beautiful DnD, or native HTML5 drag-and-drop

### Backend Architecture (Enterprise-Grade, Shopify-Inspired):

#### Core Infrastructure:
- **API Protocol**: REST API (v1) + GraphQL for flexible queries
- **Authentication**: OAuth 2.0, API keys, JWT tokens with refresh mechanism
- **Database**: PostgreSQL for relational data + Redis for caching/sessions
- **Asset Storage**: AWS S3 or equivalent cloud storage (CDN-enabled)
- **Message Queue**: RabbitMQ/Kafka for async operations (analytics, emails, webhooks)
- **Search**: Elasticsearch for layout/component/asset search
- **Monitoring**: ELK Stack, DataDog, or New Relic for performance tracking

---

## 1. Authentication & User Management

### Login System (OAuth 2.0 + Social Login):
```
┌─────────────────┐
│  Login Methods  │
├─────────────────┤
│ • Email/Pass    │
│ • Google OAuth  │
│ • GitHub        │
│ • Microsoft     │
│ • SSO (SAML)    │
└─────────────────┘
```

#### API Endpoints:
```
POST   /api/v1/auth/register
POST   /api/v1/auth/login
POST   /api/v1/auth/logout
POST   /api/v1/auth/refresh-token
POST   /api/v1/auth/forgot-password
POST   /api/v1/auth/reset-password
GET    /api/v1/auth/me (Get current user)
POST   /api/v1/auth/verify-email
POST   /api/v1/auth/2fa/setup
POST   /api/v1/auth/2fa/verify
```

#### User Model:
```json
{
  "user": {
    "id": "user_abc123",
    "email": "designer@example.com",
    "first_name": "Jane",
    "last_name": "Designer",
    "phone": "+1234567890",
    "avatar_url": "https://cdn.example.com/avatars/user_abc123.jpg",
    "role": "owner|admin|editor|viewer",
    "status": "active|suspended|deleted",
    "subscription_plan": "free|starter|professional|enterprise",
    "created_at": "2024-01-15T10:30:00Z",
    "updated_at": "2024-03-07T15:45:30Z",
    "two_factor_enabled": false,
    "preferences": {
      "theme": "light|dark",
      "language": "en|es|fr|de|ja",
      "timezone": "America/New_York",
      "notifications_enabled": true,
      "email_digest": "daily|weekly|none"
    }
  }
}
```

#### Session Management:
- **JWT Tokens**: Short-lived (15 min) access tokens + long-lived (7 days) refresh tokens
- **Session Storage**: Redis with automatic expiration
- **CSRF Protection**: Token-based protection for state-changing requests
- **Rate Limiting**: 100 requests/minute per user (Shopify-style tiered limits)

#### Permission Model (Role-Based Access Control):
```
┌─────────────────────────────────────────┐
│ Role        │ Projects │ Edit │ Delete   │
├─────────────────────────────────────────┤
│ Owner       │ All      │ Yes  │ Yes      │
│ Admin       │ All      │ Yes  │ Limited  │
│ Editor      │ Assigned │ Yes  │ No       │
│ Viewer      │ Assigned │ No   │ No       │
└─────────────────────────────────────────┘
```

---

## 2. Analytics & Insights (Like Shopify Reports)

### Analytics Dashboard Endpoints:
```
GET    /api/v1/analytics/overview
GET    /api/v1/analytics/projects/summary
GET    /api/v1/analytics/layouts/performance
GET    /api/v1/analytics/users/activity
GET    /api/v1/analytics/exports/statistics
GET    /api/v1/analytics/components/usage
```

### Analytics Data Models:

#### Project Analytics:
```json
{
  "analytics": {
    "date_range": {
      "start": "2024-02-01",
      "end": "2024-03-07"
    },
    "projects": {
      "total_created": 245,
      "total_active": 189,
      "growth_rate": 12.5,
      "by_category": {
        "e-commerce": 87,
        "saas": 62,
        "marketing": 40
      }
    },
    "layouts": {
      "total_published": 512,
      "total_drafts": 298,
      "average_components_per_layout": 24,
      "most_used_components": [
        { "name": "button", "usage_count": 3421, "percentage": 18.5 },
        { "name": "card", "usage_count": 2156, "percentage": 11.6 },
        { "name": "input", "usage_count": 1895, "percentage": 10.2 }
      ]
    },
    "performance": {
      "average_load_time_ms": 245,
      "average_interaction_time_ms": 180,
      "mobile_adoption_rate": 62,
      "export_conversion_rate": 34.8
    },
    "exports": {
      "total_exports": 1240,
      "by_format": {
        "html": 480,
        "react": 456,
        "vue": 204,
        "json": 100
      },
      "by_period": [
        { "week": "2024-02-26", "count": 320 },
        { "week": "2024-03-04", "count": 380 }
      ]
    }
  }
}
```

#### User Activity Analytics:
```json
{
  "user_analytics": {
    "total_users": 3421,
    "active_users": {
      "daily": 892,
      "weekly": 1245,
      "monthly": 2156
    },
    "user_segments": {
      "free": 1890,
      "starter": 876,
      "professional": 543,
      "enterprise": 112
    },
    "engagement": {
      "average_session_duration_minutes": 18.5,
      "average_projects_per_user": 3.2,
      "feature_adoption": {
        "drag_drop": 94.2,
        "responsive_design": 67.3,
        "collaboration": 43.1,
        "analytics": 51.8
      }
    },
    "retention": {
      "day_1": 85.2,
      "day_7": 62.1,
      "day_30": 48.3,
      "monthly_churn_rate": 3.2
    }
  }
}
```

#### Layout Performance Tracking:
```json
{
  "layout_performance": {
    "layout_id": "layout_xyz789",
    "views": 1523,
    "exports": 34,
    "shares": 128,
    "comments": 45,
    "collaborators": 8,
    "time_to_completion_hours": 2.5,
    "component_statistics": {
      "total_components": 42,
      "unique_components": 15,
      "largest_component_size_kb": 234
    },
    "browser_breakdown": {
      "chrome": 68.5,
      "firefox": 15.2,
      "safari": 12.3,
      "other": 4.0
    },
    "device_breakdown": {
      "desktop": 72.5,
      "tablet": 18.3,
      "mobile": 9.2
    }
  }
}
```

### Analytics Events (Mixpanel/Segment Style):
- `layout.created`
- `layout.published`
- `layout.exported`
- `component.added`
- `component.removed`
- `collaboration.invited`
- `project.shared`
- `user.logged_in`
- `user.subscription_upgraded`

---

## 3. Transactions & Billing (Shopify Subscriptions Model)

### Subscription Plans:
```
┌──────────────────────────────────────────────────┐
│ Plan         │ Monthly │ Annual │ Features       │
├──────────────────────────────────────────────────┤
│ Free         │ $0      │ -      │ 5 projects     │
│ Starter      │ $29     │ $290   │ 50 projects    │
│ Professional │ $99     │ $990   │ Unlimited      │
│ Enterprise   │ Custom  │ Custom │ Custom + SLA   │
└──────────────────────────────────────────────────┘
```

### Transaction Endpoints:
```
POST   /api/v1/billing/checkout
POST   /api/v1/billing/subscribe
POST   /api/v1/billing/upgrade-plan
POST   /api/v1/billing/cancel-subscription
GET    /api/v1/billing/subscription
GET    /api/v1/billing/invoices
GET    /api/v1/billing/usage
POST   /api/v1/billing/apply-coupon
```

#### Subscription Model:
```json
{
  "subscription": {
    "id": "sub_abc123xyz",
    "user_id": "user_abc123",
    "plan_id": "plan_professional",
    "status": "active|trialing|past_due|canceled",
    "current_period_start": "2024-02-15T00:00:00Z",
    "current_period_end": "2024-03-15T00:00:00Z",
    "billing_cycle": "monthly|annual",
    "price": 99.00,
    "currency": "USD",
    "auto_renew": true,
    "trial_end": null,
    "trial_days_remaining": 0,
    "cancel_at_period_end": false,
    "metadata": {
      "team_name": "Design Co",
      "team_size": 5,
      "projects_limit": -1
    }
  }
}
```

#### Invoice Model:
```json
{
  "invoice": {
    "id": "inv_xyz789abc",
    "subscription_id": "sub_abc123xyz",
    "amount": 99.00,
    "currency": "USD",
    "status": "paid|pending|failed|draft",
    "issue_date": "2024-02-15T00:00:00Z",
    "due_date": "2024-03-15T00:00:00Z",
    "paid_date": "2024-02-16T14:23:00Z",
    "description": "Professional Plan - Monthly",
    "line_items": [
      {
        "description": "Professional Plan",
        "quantity": 1,
        "unit_price": 99.00,
        "total": 99.00
      }
    ],
    "discount_applied": 0,
    "tax": 0,
    "total": 99.00,
    "payment_method": {
      "type": "card",
      "brand": "visa",
      "last_4": "4242",
      "expiry": "12/25"
    }
  }
}
```

#### Usage Tracking:
```json
{
  "usage": {
    "period": {
      "start": "2024-02-15T00:00:00Z",
      "end": "2024-03-15T00:00:00Z"
    },
    "plan_limits": {
      "projects": -1,
      "team_members": 5,
      "storage_gb": 100,
      "monthly_exports": 1000,
      "api_calls": 100000
    },
    "current_usage": {
      "projects": 12,
      "team_members": 3,
      "storage_gb": 23.4,
      "monthly_exports": 342,
      "api_calls": 54321
    },
    "percentage_used": {
      "projects": 0,
      "team_members": 60,
      "storage": 23.4,
      "exports": 34.2,
      "api_calls": 54.3
    }
  }
}
```

#### Payment Processing:
- **Stripe Integration**: For credit card payments (PCI-DSS compliant)
- **Webhook Handling**: Real-time payment status updates
- **Retry Logic**: Automatic retry for failed payments (Shopify-style)
- **Dunning Management**: Re-engagement emails for payment failures
- **Proration**: Automatic credit/debit for mid-cycle changes
- **Tax Calculation**: Automatic sales tax based on location

---

## 4. Geo & Location Features (Shopify Multi-Region)

### Geo Endpoints:
```
GET    /api/v1/geo/regions
GET    /api/v1/geo/currencies
GET    /api/v1/geo/user-location
GET    /api/v1/geo/analytics/by-region
POST   /api/v1/geo/set-region
```

#### Supported Regions & Currencies:
```json
{
  "regions": [
    {
      "region_id": "region_us",
      "name": "United States",
      "country_code": "US",
      "timezone": "America/New_York",
      "currencies": ["USD"],
      "language": "en-US",
      "tax_rate": 0
    },
    {
      "region_id": "region_eu",
      "name": "European Union",
      "country_code": "EU",
      "timezone": "Europe/London",
      "currencies": ["EUR", "GBP"],
      "language": "en-GB",
      "tax_rate": 0.21,
      "vat_id_required": true,
      "gdpr_compliant": true
    },
    {
      "region_id": "region_apac",
      "name": "Asia-Pacific",
      "country_code": "AP",
      "timezone": "Asia/Tokyo",
      "currencies": ["JPY", "AUD", "SGD"],
      "language": "en-US",
      "tax_rate": 0.08
    }
  ]
}
```

#### User Geo Profile:
```json
{
  "user_geo": {
    "user_id": "user_abc123",
    "ip_address": "203.0.113.45",
    "detected_location": {
      "country": "United States",
      "country_code": "US",
      "region": "California",
      "city": "San Francisco",
      "latitude": 37.7749,
      "longitude": -122.4194,
      "timezone": "America/Los_Angeles",
      "currency": "USD"
    },
    "preferred_region": "region_us",
    "preferred_language": "en-US",
    "preferred_currency": "USD",
    "vat_id": null,
    "last_login_location": {
      "country": "United States",
      "city": "San Francisco",
      "timestamp": "2024-03-07T15:30:00Z"
    },
    "locations_history": [
      {
        "country": "United States",
        "city": "New York",
        "accessed_at": "2024-03-05T09:15:00Z"
      }
    ]
  }
}
```

#### Regional Analytics:
```json
{
  "analytics_by_region": {
    "period": "monthly",
    "date": "2024-03",
    "regions": [
      {
        "region": "US",
        "users": 1240,
        "projects": 3890,
        "revenue": 28450.00,
        "mrr_growth": 12.5,
        "churn_rate": 2.1,
        "avg_session_duration_minutes": 22.3
      },
      {
        "region": "EU",
        "users": 680,
        "projects": 2145,
        "revenue": 18900.00,
        "mrr_growth": 8.3,
        "churn_rate": 3.2,
        "avg_session_duration_minutes": 19.8
      },
      {
        "region": "APAC",
        "users": 420,
        "projects": 1230,
        "revenue": 9450.00,
        "mrr_growth": 18.9,
        "churn_rate": 1.8,
        "avg_session_duration_minutes": 25.1
      }
    ]
  }
}
```

#### Localization & Language Support:
```json
{
  "localization": {
    "supported_languages": [
      "en-US", "en-GB", "es-ES", "fr-FR",
      "de-DE", "it-IT", "ja-JP", "zh-CN",
      "ko-KR", "pt-BR", "ru-RU", "ar-SA"
    ],
    "supported_currencies": [
      "USD", "EUR", "GBP", "JPY", "AUD",
      "CAD", "CHF", "CNY", "INR", "MXN"
    ],
    "user_preferences": {
      "language": "en-US",
      "currency": "USD",
      "date_format": "MM/DD/YYYY",
      "time_format": "12h"
    }
  }
}
```

#### CDN & Content Delivery:
- **Global CDN**: CloudFlare/AWS CloudFront for asset distribution
- **Regional Caching**: Local caches in each region (US, EU, APAC, etc.)
- **Latency Optimization**: Automatic region selection based on user location
- **DDoS Protection**: Regional firewalls and rate limiting

---

## 5. Webhooks & Event System (Real-Time Updates)

### Webhook Events:
```
user.created
user.updated
user.deleted
project.created
project.updated
project.deleted
layout.published
layout.exported
subscription.created
subscription.updated
subscription.canceled
payment.succeeded
payment.failed
```

### Webhook Endpoint:
```
POST   /api/v1/webhooks/subscribe
GET    /api/v1/webhooks/list
DELETE /api/v1/webhooks/{webhook_id}
```

#### Webhook Payload (Example):
```json
{
  "id": "evt_abc123xyz",
  "type": "layout.exported",
  "timestamp": "2024-03-07T15:30:00Z",
  "data": {
    "layout_id": "layout_xyz789",
    "project_id": "proj_123",
    "user_id": "user_abc123",
    "export_format": "react",
    "export_size_kb": 245
  },
  "signature": "sha256=...",
  "delivery_attempt": 1
}
```

---

## 6. Mobile App Export (iOS & Android)

### Export Endpoints:
```
POST   /api/v1/export/ios-swift
POST   /api/v1/export/ios-swiftui
POST   /api/v1/export/android-kotlin
POST   /api/v1/export/android-compose
POST   /api/v1/export/react-native
POST   /api/v1/export/flutter
GET    /api/v1/export/{export_id}/status
GET    /api/v1/export/{export_id}/download
```

### iOS Export Features

#### SwiftUI Export:
- **Auto-generated Swift UI code** with component mapping
- **Safe Area & Notch handling** for all iPhone models
- **Dynamic Type support** for accessibility
- **Dark Mode support** (light/dark theme variants)
- **VStack/HStack/ZStack** layout composition
- **@State management** for interactive components
- **Navigation support** (NavigationLink, NavigationStack)
- **Form handling** with @StateObject binding
- **Image handling** with AsyncImage and caching
- **Modifiers** for styling (padding, background, cornerRadius, etc.)

#### Generated Swift Code Example:
```swift
import SwiftUI

struct DashboardView: View {
    @State private var buttonTapped = false
    @State private var inputText = ""
    
    var body: some View {
        ZStack {
            // Background
            Color(#colorLiteral(red: 0.98, green: 0.98, blue: 0.98, alpha: 1))
                .ignoresSafeArea()
            
            VStack(spacing: 16) {
                // Header Card
                VStack(alignment: .leading, spacing: 8) {
                    Text("Welcome back")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.black)
                    
                    Text("Dashboard overview")
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(.gray)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(16)
                .background(Color.white)
                .cornerRadius(8)
                
                // Input Field
                TextField("Search projects", text: $inputText)
                    .padding(12)
                    .background(Color(.systemGray6))
                    .cornerRadius(6)
                    .font(.system(size: 14))
                
                // Action Button
                Button(action: { buttonTapped.toggle() }) {
                    Text("Create New Project")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(12)
                        .background(Color(#colorLiteral(red: 0.0, green: 0.48, blue: 1.0, alpha: 1)))
                        .cornerRadius(6)
                }
                
                Spacer()
            }
            .padding(16)
        }
    }
}

#Preview {
    DashboardView()
}
```

#### iOS Project Structure:
```
YourApp.xcodeproj/
├── YourApp/
│   ├── App/
│   │   ├── YourAppApp.swift
│   │   └── ContentView.swift
│   ├── Views/
│   │   ├── DashboardView.swift
│   │   ├── ProjectListView.swift
│   │   └── SettingsView.swift
│   ├── ViewModels/
│   │   ├── DashboardViewModel.swift
│   │   └── ProjectViewModel.swift
│   ├── Models/
│   │   ├── Project.swift
│   │   ├── User.swift
│   │   └── Layout.swift
│   ├── Services/
│   │   ├── APIService.swift
│   │   ├── AuthService.swift
│   │   └── StorageService.swift
│   ├── Resources/
│   │   ├── Assets.xcassets/
│   │   ├── Localizable.strings
│   │   └── Info.plist
│   └── Utilities/
│       ├── Constants.swift
│       ├── Extensions.swift
│       └── Helpers.swift
```

---

### Android Export Features

#### Kotlin + Jetpack Compose Export:
- **Auto-generated Kotlin/Compose code** with component mapping
- **Material Design 3 support** (Material You)
- **Adaptive layouts** for phones, tablets, and foldables
- **Dark/Light theme** automatic switching
- **State management** with remember {} and ViewModel
- **Navigation Compose** for multi-screen apps
- **Accessibility support** (contentDescription, semantics)
- **LazyColumn/LazyRow** for efficient lists
- **Flow layouts** and responsive grids
- **Image loading** with Coil integration
- **Network requests** with Retrofit/OkHttp

#### Generated Kotlin Code Example:
```kotlin
package com.example.myapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun DashboardScreen(viewModel: DashboardViewModel = viewModel()) {
    val buttonTapped = remember { mutableStateOf(false) }
    val inputText = remember { mutableStateOf("") }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFAFAFA))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.Start
        ) {
            // Header Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "Welcome back",
                        fontSize = 24.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                        color = Color.Black
                    )
                    
                    Text(
                        "Dashboard overview",
                        fontSize = 14.sp,
                        color = Color.Gray
                    )
                }
            }
            
            // Search Input
            OutlinedTextField(
                value = inputText.value,
                onValueChange = { inputText.value = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                placeholder = { Text("Search projects") },
                shape = RoundedCornerShape(6.dp)
            )
            
            // Action Button
            Button(
                onClick = { buttonTapped.value = !buttonTapped.value },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF0078FF)
                ),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    "Create New Project",
                    fontSize = 16.sp,
                    color = Color.White
                )
            }
            
            Spacer(modifier = Modifier.weight(1f))
        }
    }
}

@Composable
@Preview(showBackground = true)
fun DashboardScreenPreview() {
    DashboardScreen()
}
```

#### Android Project Structure:
```
app/
├── src/
│   └── main/
│       ├── kotlin/com/example/myapp/
│       │   ├── MainActivity.kt
│       │   ├── ui/
│       │   │   ├── screens/
│       │   │   │   ├── DashboardScreen.kt
│       │   │   │   ├── ProjectListScreen.kt
│       │   │   │   └── SettingsScreen.kt
│       │   │   ├── theme/
│       │   │   │   ├── Color.kt
│       │   │   │   ├── Type.kt
│       │   │   │   └── Theme.kt
│       │   │   └── components/
│       │   │       ├── ProjectCard.kt
│       │   │       ├── TopBar.kt
│       │   │       └── BottomNav.kt
│       │   ├── viewmodel/
│       │   │   ├── DashboardViewModel.kt
│       │   │   └── ProjectViewModel.kt
│       │   ├── model/
│       │   │   ├── Project.kt
│       │   │   ├── User.kt
│       │   │   └── Layout.kt
│       │   ├── network/
│       │   │   ├── ApiService.kt
│       │   │   ├── RetrofitClient.kt
│       │   │   └── AuthInterceptor.kt
│       │   ├── repository/
│       │   │   └── ProjectRepository.kt
│       │   └── util/
│       │       ├── Constants.kt
│       │       └── Extensions.kt
│       ├── res/
│       │   ├── drawable/
│       │   ├── values/
│       │   │   ├── strings.xml
│       │   │   ├── colors.xml
│       │   │   └── themes.xml
│       │   └── xml/
│       └── AndroidManifest.xml
└── build.gradle.kts
```

---

### React Native Export

#### Features:
- **Cross-platform code sharing** (iOS + Android from single codebase)
- **Expo or Bare React Native** option
- **Safe Area handling** with SafeAreaView
- **Platform-specific styling** (ios/android)
- **Navigation with React Navigation** (Stack, Tab, Drawer)
- **State management** with Redux, Zustand, or Context API
- **Native modules** for platform-specific features
- **Image handling** with react-native-fast-image
- **Networking** with Axios/Fetch
- **Local storage** with AsyncStorage/SQLite

#### Generated React Native Code Example:
```javascript
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  StyleSheet,
  useColorScheme,
} from 'react-native';

const DashboardScreen = () => {
  const [buttonTapped, setButtonTapped] = useState(false);
  const [inputText, setInputText] = useState('');
  const isDarkMode = useColorScheme() === 'dark';

  return (
    <SafeAreaView
      style={[
        styles.container,
        { backgroundColor: isDarkMode ? '#1a1a1a' : '#fafafa' },
      ]}
    >
      <View style={styles.content}>
        {/* Header Card */}
        <View
          style={[
            styles.card,
            { backgroundColor: isDarkMode ? '#2a2a2a' : '#ffffff' },
          ]}
        >
          <Text
            style={[
              styles.title,
              { color: isDarkMode ? '#ffffff' : '#000000' },
            ]}
          >
            Welcome back
          </Text>
          <Text style={styles.subtitle}>Dashboard overview</Text>
        </View>

        {/* Search Input */}
        <TextInput
          style={[
            styles.input,
            { backgroundColor: isDarkMode ? '#333333' : '#f5f5f5' },
            { color: isDarkMode ? '#ffffff' : '#000000' },
          ]}
          placeholder="Search projects"
          placeholderTextColor={isDarkMode ? '#999999' : '#cccccc'}
          value={inputText}
          onChangeText={setInputText}
        />

        {/* Action Button */}
        <TouchableOpacity
          style={styles.button}
          onPress={() => setButtonTapped(!buttonTapped)}
          activeOpacity={0.8}
        >
          <Text style={styles.buttonText}>Create New Project</Text>
        </TouchableOpacity>

        <View style={{ flex: 1 }} />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  card: {
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: '#999999',
  },
  input: {
    borderRadius: 6,
    padding: 12,
    marginBottom: 16,
    fontSize: 14,
  },
  button: {
    backgroundColor: '#0078FF',
    borderRadius: 6,
    padding: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default DashboardScreen;
```

---

### Flutter Export

#### Features:
- **Dart code generation** with Material & Cupertino widgets
- **Multi-platform support** (iOS, Android, Web, Desktop)
- **StatefulWidget/StatelessWidget** composition
- **Theme support** (light/dark with Material 3)
- **Navigation** with GoRouter or Navigator
- **Form handling** with TextFormField and validation
- **Image loading** with cached_network_image
- **HTTP requests** with Dio or http package
- **State management** with Provider, Riverpod, or BLoC

#### Generated Flutter Code Example:
```dart
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CMS Export',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0078FF),
        ),
      ),
      home: const DashboardScreen(),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  bool _buttonTapped = false;
  final _inputController = TextEditingController();

  @override
  void dispose() {
    _inputController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header Card
                Card(
                  elevation: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Welcome back',
                          style: Theme.of(context)
                              .textTheme
                              .headlineLarge
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Dashboard overview',
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium
                              ?.copyWith(color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Search Input
                TextField(
                  controller: _inputController,
                  decoration: InputDecoration(
                    hintText: 'Search projects',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(6),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 12,
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Action Button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _buttonTapped = !_buttonTapped;
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ),
                    child: const Text('Create New Project'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
```

---

### Export Configuration & Options

#### Mobile Export Dialog:
```json
{
  "export_options": {
    "platform": "ios|android|react-native|flutter",
    "ios_options": {
      "framework": "swiftui|uikit",
      "min_ios_version": "14.0|15.0|16.0|17.0",
      "include_tests": true,
      "include_ci_cd": true,
      "package_name": "com.company.appname",
      "team_id": "ABCD12EFG",
      "bundle_id": "com.company.appname"
    },
    "android_options": {
      "framework": "compose|xml",
      "min_sdk": "24|26|28|29",
      "target_sdk": "34",
      "package_name": "com.company.appname",
      "app_name": "My App",
      "include_tests": true,
      "include_ci_cd": true,
      "kotlin_version": "1.9.0"
    },
    "rn_options": {
      "runtime": "expo|bare",
      "navigation": "react-navigation|native-stack",
      "state_management": "redux|zustand|context",
      "include_template": true
    },
    "flutter_options": {
      "state_management": "provider|riverpod|bloc",
      "min_sdk": "21",
      "include_tests": true,
      "pubspec_templates": true
    },
    "common_options": {
      "include_api_client": true,
      "include_auth_flow": true,
      "api_base_url": "https://api.example.com/v1",
      "generate_models": true,
      "include_dark_mode": true,
      "include_localization": true,
      "supported_languages": ["en", "es", "fr"]
    }
  }
}
```

---

### Mobile Export Workflow

#### Step 1: Export Initiation
```
POST /api/v1/export/ios-swiftui
{
  "layout_id": "layout_xyz789",
  "project_id": "proj_123",
  "options": {
    "framework": "swiftui",
    "min_ios_version": "15.0",
    "bundle_id": "com.mycompany.myapp"
  }
}
```

#### Response:
```json
{
  "export_id": "exp_abc123xyz",
  "status": "processing",
  "progress": 0,
  "estimated_time_seconds": 45,
  "created_at": "2024-03-07T15:30:00Z"
}
```

#### Step 2: Monitor Progress
```
GET /api/v1/export/exp_abc123xyz/status
```

#### Response:
```json
{
  "export_id": "exp_abc123xyz",
  "status": "completed",
  "progress": 100,
  "files": [
    {
      "name": "DashboardView.swift",
      "size_kb": 45,
      "path": "Views/DashboardView.swift"
    },
    {
      "name": "DashboardViewModel.swift",
      "size_kb": 23,
      "path": "ViewModels/DashboardViewModel.swift"
    }
  ],
  "download_url": "https://cdn.example.com/exports/exp_abc123xyz/MyApp.zip",
  "expires_at": "2024-03-14T15:30:00Z",
  "total_size_mb": 2.5
}
```

#### Step 3: Download Artifact
```
GET /api/v1/export/exp_abc123xyz/download
```
Returns a ZIP file containing:
- Complete project structure
- Source code files
- Configuration files
- Build scripts
- Documentation

---

### Component Mapping to Native Code

#### Mapping Strategy:
```
CMS Component → iOS (SwiftUI) → Android (Compose) → React Native → Flutter

Button → Button → Button → TouchableOpacity/Pressable → ElevatedButton
Card → ZStack + RoundedRectangle → Card → View → Card
Input → TextField → OutlinedTextField → TextInput → TextField
Text → Text → Text → Text → Text
Image → Image/AsyncImage → Image → Image → Image
List → List/ForEach → LazyColumn → FlatList → ListView
Modal → Sheet/Presentation → Dialog → Modal → AlertDialog
```

#### Advanced Mapping:
```
CMS Custom Component → Code Generator → Native Equivalent
├── Mapping Logic
├── Style Translation
├── Event Handling
└── State Management
```

---

### Export Features & Capabilities

#### Supported Features:
- ✅ **Layout export** (absolute, flex, grid positioning)
- ✅ **Styling** (colors, fonts, spacing, shadows)
- ✅ **Responsive design** (device-specific layouts)
- ✅ **Interactions** (button press, input change, form submit)
- ✅ **Navigation** (screen transitions, deep linking)
- ✅ **Forms** (validation, submission, state management)
- ✅ **Images** (optimization, caching, placeholders)
- ✅ **Dark mode** (automatic theme switching)
- ✅ **Accessibility** (labels, hints, semantic structure)
- ✅ **Localization** (multi-language strings)
- ✅ **API integration** (auto-generated service layer)
- ✅ **Authentication** (login flow, token management)

#### Not Yet Supported:
- ❌ Custom native modules (must be added manually)
- ❌ Device-specific permissions handling (partial)
- ❌ In-app purchases (template only)
- ❌ Push notifications (service layer only)
- ❌ Camera/location (API only)

---

### Post-Export Integration

#### iOS Integration Checklist:
1. ✓ Open `.xcworkspace` in Xcode (not `.xcodeproj`)
2. ✓ Update bundle ID and team ID in target settings
3. ✓ Configure signing certificates
4. ✓ Update API endpoints in `Constants.swift`
5. ✓ Add cocoapods dependencies (run `pod install`)
6. ✓ Build and run on simulator/device

#### Android Integration Checklist:
1. ✓ Update `package` name in `build.gradle.kts`
2. ✓ Configure signing keystore in `local.properties`
3. ✓ Update API endpoints in `Constants.kt`
4. ✓ Run `./gradlew build` to compile
5. ✓ Update Firebase/Analytics credentials if needed
6. ✓ Test on emulator/physical device

#### React Native Integration Checklist:
1. ✓ Run `npm install` or `yarn install`
2. ✓ Update API endpoints in `.env`
3. ✓ Install pods (iOS): `cd ios && pod install`
4. ✓ Update signing certificates (iOS Keychain)
5. ✓ Configure signing for Android in `build.gradle`
6. ✓ Run `npm run ios` / `npm run android`

#### Flutter Integration Checklist:
1. ✓ Run `flutter pub get`
2. ✓ Update API endpoints in config files
3. ✓ Generate native icons and splash screens
4. ✓ Configure Firebase (if using)
5. ✓ Update iOS signing in Xcode
6. ✓ Update Android signing in gradle
7. ✓ Run `flutter run` or `flutter build`

---

## 7. Website Export (Production-Ready Sites)

### Export Endpoints:
```
POST   /api/v1/export/website-nextjs
POST   /api/v1/export/website-react
POST   /api/v1/export/website-vue
POST   /api/v1/export/website-html
POST   /api/v1/export/website-shopify
POST   /api/v1/export/website-wordpress
GET    /api/v1/export/{export_id}/status
GET    /api/v1/export/{export_id}/download
GET    /api/v1/export/{export_id}/preview
```

### Website Export Features

#### Next.js Export (Recommended - Server-Side Rendering)
- **Full-stack framework** with API routes
- **Server-side rendering** for SEO
- **Static generation** for fast performance
- **Image optimization** with next/image
- **Built-in routing** for multi-page sites
- **API routes** for backend (scaffolded)
- **Incremental static regeneration** for updates
- **Automatic code splitting** & optimization
- **TypeScript support** for type safety

#### React SPA Export (Client-Side Rendering)
- **Create React App** or **Vite** scaffolding
- **React Router** for navigation
- **State management** (Redux, Zustand, Context)
- **Component library** (Material-UI, Tailwind UI)
- **Automatic code splitting** with lazy loading
- **Build optimization** & minification
- **Development server** with hot reload
- **Testing setup** (Jest, React Testing Library)

#### Vue Export (Client-Side Rendering)
- **Vue 3 Composition API**
- **Vue Router** for navigation
- **Pinia** for state management
- **Vite** build tool for speed
- **Component library** options
- **TypeScript support**
- **Testing framework** setup

#### Static HTML/CSS Export (Simplest)
- **Plain HTML & CSS** - no dependencies
- **Responsive design** out-of-the-box
- **Zero build process** - host anywhere
- **SEO-friendly** semantics
- **Accessibility** standards compliant
- **CSS frameworks** (Tailwind, Bootstrap)
- **JavaScript libraries** for interactivity
- **Optimized assets** with compression

#### Shopify Theme Export
- **Liquid template syntax** for Shopify
- **Custom sections** for page builder
- **Metafields** integration
- **Product loops** & collections
- **Cart functionality** scaffolding
- **Payment integration** ready
- **Theme assets** structure
- **Installable to Shopify** store

#### WordPress Theme Export
- **PHP theme structure**
- **Custom post types** support
- **Gutenberg blocks** ready
- **Widget areas** configured
- **Theme customizer** options
- **Child theme** scaffolding
- **Plugin compatibility**
- **WooCommerce** integration optional

### Generated Website Examples

#### Next.js Project Structure
```
myapp/
├── pages/
│   ├── index.js (home page)
│   ├── coaching/
│   │   ├── index.js (coaching list)
│   │   └── [id].js (coaching detail)
│   ├── pricing.js
│   ├── contact.js
│   ├── _app.js (app wrapper)
│   ├── _document.js (HTML template)
│   └── api/
│       ├── auth/
│       │   ├── login.js (TODO: implement)
│       │   └── signup.js (TODO: implement)
│       ├── meals/
│       │   └── [...slug].js (dynamic routes)
│       └── coaches/
│           └── index.js (TODO: connect API)
│
├── components/
│   ├── Navigation.js (generated from design)
│   ├── Footer.js (generated from design)
│   ├── CoachCard.js (generated from component)
│   ├── MealForm.js (generated from form)
│   ├── PricingCard.js (generated from design)
│   └── layouts/
│       └── BaseLayout.js
│
├── styles/
│   ├── globals.css (Tailwind, generated)
│   └── variables.css (design tokens)
│
├── lib/
│   ├── api.js (API client - TODO: endpoints)
│   ├── auth.js (authentication scaffold)
│   └── utils.js
│
├── public/
│   ├── favicon.ico
│   ├── images/ (user-uploaded)
│   └── icons/ (generated)
│
├── next.config.js (configuration)
├── package.json (dependencies)
├── tsconfig.json (TypeScript config)
├── .env.local.example (TODO: fill in)
└── README.md (setup instructions)
```

#### React (Vite) Project Structure
```
myapp/
├── src/
│   ├── pages/
│   │   ├── Home.jsx
│   │   ├── Coaching.jsx
│   │   ├── Pricing.jsx
│   │   ├── Contact.jsx
│   │   └── NotFound.jsx
│   │
│   ├── components/
│   │   ├── Navigation.jsx (generated)
│   │   ├── Footer.jsx (generated)
│   │   ├── CoachCard.jsx (generated)
│   │   ├── Hero.jsx (generated)
│   │   └── layout/
│   │       └── MainLayout.jsx
│   │
│   ├── hooks/
│   │   ├── useAuth.js (scaffold)
│   │   └── useApi.js
│   │
│   ├── context/
│   │   └── AuthContext.jsx
│   │
│   ├── services/
│   │   ├── api.js (TODO: endpoints)
│   │   └── auth.js (scaffold)
│   │
│   ├── styles/
│   │   ├── index.css (Tailwind)
│   │   └── variables.css
│   │
│   ├── App.jsx (router setup)
│   └── main.jsx (entry point)
│
├── vite.config.js
├── package.json
├── .env.example
└── README.md
```

#### Static HTML Export
```
mywebsite/
├── index.html (home page)
├── coaching/
│   ├── index.html
│   └── coach-john/
│       └── index.html
├── pricing.html
├── contact.html
├── about.html
│
├── css/
│   ├── style.css (generated from design)
│   └── responsive.css
│
├── js/
│   ├── main.js (TODO: add interactivity)
│   ├── forms.js (form submission)
│   └── navigation.js (mobile menu)
│
├── images/
│   ├── logo.png
│   ├── hero-image.jpg
│   └── coaches/
│       ├── coach-1.jpg
│       └── coach-2.jpg
│
└── assets/
    ├── fonts/
    └── icons/
```

#### Shopify Theme Export
```
myapp.myshopify.com/
├── theme/
│   ├── templates/
│   │   ├── index.json (home)
│   │   ├── page.json (generic page)
│   │   ├── product.json (product page)
│   │   ├── collection.json (category)
│   │   └── article.json (blog)
│   │
│   ├── sections/
│   │   ├── hero.liquid (generated)
│   │   ├── coaching-grid.liquid (generated)
│   │   ├── pricing-cards.liquid (generated)
│   │   ├── testimonials.liquid (optional)
│   │   └── footer.liquid (generated)
│   │
│   ├── snippets/
│   │   ├── coach-card.liquid
│   │   ├── price-badge.liquid
│   │   └── navigation.liquid
│   │
│   ├── assets/
│   │   ├── theme.css (Tailwind generated)
│   │   ├── theme.js (TODO: interactions)
│   │   └── images/
│   │
│   ├── config/
│   │   └── settings_schema.json (customizer config)
│   │
│   └── layout/
│       └── theme.liquid (main template)
│
└── README.md (setup instructions)
```

#### WordPress Theme Export
```
mywebsite/wp-content/themes/mycoach/
├── template-parts/
│   ├── header.php (generated)
│   ├── footer.php (generated)
│   ├── navigation.php (generated)
│   └── content-coaching.php
│
├── inc/
│   ├── customizer.php (theme options)
│   ├── cpt-coach.php (custom post type)
│   ├── metaboxes.php (custom fields)
│   └── widgets.php (widget areas)
│
├── css/
│   ├── style.css (Tailwind generated)
│   └── responsive.css
│
├── js/
│   ├── main.js (TODO: interactivity)
│   └── navigation.js (mobile menu)
│
├── images/
│   ├── logo.png
│   └── screenshot.png (theme thumbnail)
│
├── page.php (generic page template)
├── single.php (single post template)
├── index.php (main template)
├── header.php (HTML head)
├── footer.php (site footer)
├── functions.php (setup & hooks)
├── style.css (theme metadata)
└── README.md (setup instructions)
```

### Website Export Configuration

#### Export Options Dialog
```json
{
  "export_options": {
    "platform": "nextjs|react|vue|html|shopify|wordpress",
    "nextjs_options": {
      "rendering": "ssr|ssg|hybrid",
      "styling": "tailwind|styled-components|css-modules",
      "language": "javascript|typescript",
      "include_api_routes": true,
      "auth_provider": "none|nextauth|supabase|auth0"
    },
    "react_options": {
      "bundler": "vite|create-react-app",
      "routing": "react-router-v6",
      "state_management": "redux|zustand|context",
      "styling": "tailwind|emotion|styled-components",
      "language": "javascript|typescript"
    },
    "vue_options": {
      "bundler": "vite",
      "routing": "vue-router",
      "state_management": "pinia|composition-api",
      "styling": "tailwind|sass",
      "language": "javascript|typescript"
    },
    "html_options": {
      "framework": "none",
      "styling": "tailwind|bootstrap|custom-css",
      "javascript": "vanilla|minimal-libs",
      "optimization": "minified|readable"
    },
    "shopify_options": {
      "theme_name": "My Coach Theme",
      "namespace": "mycoach",
      "include_sections": true,
      "include_snippets": true,
      "customizer_settings": true
    },
    "wordpress_options": {
      "theme_name": "My Coach Theme",
      "include_cpt": true,
      "include_metaboxes": true,
      "woocommerce_ready": false,
      "polylang_ready": false
    },
    "common_options": {
      "site_title": "Carnivore Coach Pro",
      "site_description": "Your personal health coaching platform",
      "contact_email": "contact@example.com",
      "phone": "+1-234-567-8900",
      "include_forms": true,
      "include_blog": true,
      "include_analytics": true,
      "analytics_provider": "google|plausible|fathom",
      "include_newsletter": true,
      "newsletter_provider": "mailchimp|convertkit|substack",
      "include_seo": true,
      "seo_description": "...",
      "social_links": {
        "twitter": "https://twitter.com/...",
        "facebook": "https://facebook.com/...",
        "instagram": "https://instagram.com/..."
      }
    }
  }
}
```

### Generated Code Examples

#### Next.js Page (Auto-Generated)
```javascript
// Generated: pages/coaching/index.js
import Image from 'next/image';
import Link from 'next/link';
import Layout from '@/components/layouts/BaseLayout';

export default function CoachingIndex({ coaches }) {
  return (
    <Layout>
      <div className="py-12 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          {/* Generated Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">Our Coaching Programs</h1>
            <p className="text-xl text-gray-600">Choose the perfect plan for your journey</p>
          </div>

          {/* Generated Coaching Grid */}
          <div className="grid md:grid-cols-3 gap-8">
            {coaches.map(coach => (
              <Link key={coach.id} href={`/coaching/${coach.id}`}>
                <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition">
                  <Image
                    src={coach.image}
                    alt={coach.name}
                    width={400}
                    height={300}
                    className="rounded-lg mb-4"
                  />
                  <h3 className="text-xl font-bold mb-2">{coach.name}</h3>
                  <p className="text-gray-600 mb-4">{coach.bio}</p>
                  <span className="text-blue-600 font-semibold">Learn More →</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* TODO: Add filtering */}
      {/* TODO: Add search functionality */}
      {/* TODO: Add pagination */}
    </Layout>
  );
}

// TODO: Update API endpoint
export async function getStaticProps() {
  const coaches = await fetch('https://api.example.com/coaches')
    .then(res => res.json());
  
  return {
    props: { coaches },
    revalidate: 3600 // Regenerate every hour
  };
}
```

#### React Component (Auto-Generated)
```jsx
// Generated: src/components/PricingCard.jsx
import React from 'react';

export default function PricingCard({ 
  plan, 
  price, 
  features, 
  cta, 
  highlighted = false 
}) {
  return (
    <div className={`
      rounded-lg p-8 border-2 transition
      ${highlighted 
        ? 'border-blue-600 shadow-xl transform scale-105' 
        : 'border-gray-200 hover:border-blue-300'
      }
    `}>
      {/* Generated Header */}
      <h3 className="text-2xl font-bold mb-2">{plan}</h3>
      <div className="mb-6">
        <span className="text-4xl font-bold">${price}</span>
        <span className="text-gray-600">/month</span>
      </div>

      {/* Generated Feature List */}
      <ul className="mb-8 space-y-3">
        {features.map((feature, idx) => (
          <li key={idx} className="flex items-center">
            <svg className="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
            {feature}
          </li>
        ))}
      </ul>

      {/* Generated CTA Button */}
      <button className={`
        w-full py-3 rounded-lg font-semibold transition
        ${highlighted
          ? 'bg-blue-600 text-white hover:bg-blue-700'
          : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
        }
      `}>
        {cta}
      </button>

      {/* TODO: Add payment integration */}
      {/* TODO: Add form submission handler */}
    </div>
  );
}
```

#### Static HTML (Auto-Generated)
```html
<!-- Generated: index.html -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Carnivore Coach Pro - Your personal health coaching platform">
  <title>Carnivore Coach Pro</title>
  <link rel="stylesheet" href="css/style.css">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
  <!-- Generated: Navigation -->
  <nav class="bg-white shadow-lg">
    <div class="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
      <h1 class="text-2xl font-bold text-blue-600">Carnivore Coach</h1>
      <ul class="hidden md:flex space-x-6">
        <li><a href="/" class="hover:text-blue-600">Home</a></li>
        <li><a href="/coaching/" class="hover:text-blue-600">Coaching</a></li>
        <li><a href="/pricing.html" class="hover:text-blue-600">Pricing</a></li>
        <li><a href="/contact.html" class="hover:text-blue-600">Contact</a></li>
      </ul>
    </div>
  </nav>

  <!-- Generated: Hero Section -->
  <section class="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
    <div class="max-w-6xl mx-auto px-4 text-center">
      <h2 class="text-5xl font-bold mb-4">Transform Your Health</h2>
      <p class="text-xl mb-8">Get personal nutrition coaching tailored to your lifestyle</p>
      <button class="bg-white text-blue-600 px-8 py-3 rounded-lg font-bold hover:bg-gray-100">
        Get Started
      </button>
    </div>
  </section>

  <!-- Generated: Features Grid -->
  <section class="py-16 bg-gray-50">
    <div class="max-w-6xl mx-auto px-4">
      <h3 class="text-3xl font-bold text-center mb-12">Why Choose Us</h3>
      <div class="grid md:grid-cols-3 gap-8">
        <div class="bg-white p-8 rounded-lg shadow">
          <h4 class="text-xl font-bold mb-4">Expert Coaches</h4>
          <p class="text-gray-600">Certified nutrition and health professionals</p>
        </div>
        <div class="bg-white p-8 rounded-lg shadow">
          <h4 class="text-xl font-bold mb-4">Personalized Plans</h4>
          <p class="text-gray-600">Custom meal plans and coaching strategies</p>
        </div>
        <div class="bg-white p-8 rounded-lg shadow">
          <h4 class="text-xl font-bold mb-4">24/7 Support</h4>
          <p class="text-gray-600">Access your coaching resources anytime</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Generated: Footer -->
  <footer class="bg-gray-900 text-white py-12">
    <div class="max-w-6xl mx-auto px-4 text-center">
      <p>&copy; 2024 Carnivore Coach Pro. All rights reserved.</p>
    </div>
  </footer>

  <script src="js/main.js"></script>
  <!-- TODO: Add analytics -->
  <!-- TODO: Add form submission -->
</body>
</html>
```

### Website Export Workflow

#### Step 1: Select Website Platform
```
POST /api/v1/export/website-nextjs
{
  "layout_id": "layout_xyz789",
  "project_id": "proj_123",
  "options": {
    "platform": "nextjs",
    "rendering": "ssr",
    "styling": "tailwind",
    "language": "typescript",
    "site_title": "Carnivore Coach Pro",
    "site_description": "Personal health coaching",
    "include_analytics": true,
    "analytics_provider": "google"
  }
}
```

#### Step 2: Monitor Progress
```
GET /api/v1/export/exp_abc123xyz/status
```

#### Step 3: Download & Deploy
```
GET /api/v1/export/exp_abc123xyz/download
```

Returns complete website ready to:
- Deploy to Vercel (Next.js)
- Deploy to Netlify (React/Vue/HTML)
- Upload to Shopify (Shopify theme)
- Install on WordPress (WordPress theme)

### Deployment Targets

#### Next.js
- **Vercel** (recommended - 1-click deployment)
- **AWS Amplify**
- **Netlify**
- **Self-hosted** (any Node.js server)

#### React / Vue / Static HTML
- **Netlify** (recommended - free tier)
- **Vercel**
- **GitHub Pages**
- **AWS S3 + CloudFront**
- **Any static host**

#### Shopify
- **Shopify Theme Store**
- **Custom Shopify store**
- **Multi-store deployment**

#### WordPress
- **Self-hosted WordPress**
- **WordPress.com** (with custom theme)
- **Managed WordPress hosting**

---

## Database Schema Overview

```sql
-- Users Table
CREATE TABLE users (
  id UUID PRIMARY KEY,
  email VARCHAR UNIQUE NOT NULL,
  password_hash VARCHAR,
  first_name VARCHAR,
  last_name VARCHAR,
  avatar_url VARCHAR,
  role VARCHAR DEFAULT 'editor',
  subscription_plan VARCHAR DEFAULT 'free',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  deleted_at TIMESTAMP NULL
);

-- Subscriptions Table
CREATE TABLE subscriptions (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  plan_id VARCHAR NOT NULL,
  status VARCHAR DEFAULT 'active',
  current_period_start TIMESTAMP,
  current_period_end TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Analytics Events Table (Time-Series DB: ClickHouse/TimescaleDB)
CREATE TABLE analytics_events (
  event_id UUID,
  event_type VARCHAR,
  user_id UUID,
  project_id UUID,
  timestamp TIMESTAMP,
  properties JSONB
) PARTITION BY RANGE (timestamp);

-- Geo Data Table
CREATE TABLE user_geo (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  country VARCHAR,
  region VARCHAR,
  city VARCHAR,
  latitude DECIMAL,
  longitude DECIMAL,
  timezone VARCHAR,
  accessed_at TIMESTAMP DEFAULT NOW()
);

-- Invoices Table
CREATE TABLE invoices (
  id UUID PRIMARY KEY,
  subscription_id UUID REFERENCES subscriptions(id),
  amount DECIMAL,
  currency VARCHAR,
  status VARCHAR,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Mobile Exports Table
CREATE TABLE mobile_exports (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  layout_id UUID NOT NULL,
  project_id UUID NOT NULL,
  platform VARCHAR NOT NULL, -- 'ios' | 'android' | 'react-native' | 'flutter'
  framework VARCHAR NOT NULL, -- 'swiftui' | 'uikit' | 'compose' | 'xml' | 'expo' | 'bare'
  status VARCHAR DEFAULT 'processing', -- 'processing' | 'completed' | 'failed'
  progress INTEGER DEFAULT 0,
  file_size_mb DECIMAL,
  download_url VARCHAR,
  options JSONB,
  error_message VARCHAR,
  created_at TIMESTAMP DEFAULT NOW(),
  expires_at TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Mobile Export Events Table
CREATE TABLE mobile_export_events (
  id UUID PRIMARY KEY,
  export_id UUID REFERENCES mobile_exports(id),
  event_type VARCHAR, -- 'export.started' | 'export.generated' | 'export.uploaded' | 'export.completed' | 'export.failed'
  details JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Export Analytics Table
CREATE TABLE export_analytics (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  export_type VARCHAR, -- 'html' | 'react' | 'vue' | 'nextjs' | 'shopify' | 'wordpress' | 'react-native' | 'flutter' | 'ios' | 'android'
  layout_id UUID,
  count INTEGER,
  success_count INTEGER,
  failure_count INTEGER,
  average_generation_time_seconds INTEGER,
  date DATE,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Website Exports Table
CREATE TABLE website_exports (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  layout_id UUID NOT NULL,
  project_id UUID NOT NULL,
  platform VARCHAR NOT NULL, -- 'nextjs' | 'react' | 'vue' | 'html' | 'shopify' | 'wordpress'
  framework VARCHAR NOT NULL, -- 'nextjs' | 'vite' | 'cra' | etc.
  status VARCHAR DEFAULT 'processing', -- 'processing' | 'completed' | 'failed'
  progress INTEGER DEFAULT 0,
  file_size_mb DECIMAL,
  download_url VARCHAR,
  preview_url VARCHAR,
  deployment_target VARCHAR, -- 'vercel' | 'netlify' | 'shopify' | 'wordpress' | 'custom'
  options JSONB,
  error_message VARCHAR,
  created_at TIMESTAMP DEFAULT NOW(),
  expires_at TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Website Export Events Table
CREATE TABLE website_export_events (
  id UUID PRIMARY KEY,
  export_id UUID REFERENCES website_exports(id),
  event_type VARCHAR, -- 'export.started' | 'export.generated' | 'export.optimized' | 'export.deployed' | 'export.failed'
  details JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### Mobile Export Analytics Data Model:
```json
{
  "mobile_export_analytics": {
    "period": "2024-03",
    "total_exports": 1245,
    "by_platform": {
      "ios": {
        "total": 480,
        "swiftui": 320,
        "uikit": 160,
        "success_rate": 97.5,
        "avg_generation_time_seconds": 32
      },
      "android": {
        "total": 420,
        "compose": 340,
        "xml": 80,
        "success_rate": 96.2,
        "avg_generation_time_seconds": 38
      },
      "react_native": {
        "total": 230,
        "expo": 150,
        "bare": 80,
        "success_rate": 94.8,
        "avg_generation_time_seconds": 28
      },
      "flutter": {
        "total": 115,
        "success_rate": 93.0,
        "avg_generation_time_seconds": 25
      }
    },
    "most_exported_layouts": [
      {
        "layout_id": "layout_001",
        "name": "Dashboard",
        "ios_exports": 145,
        "android_exports": 128,
        "react_native_exports": 95
      }
    ],
    "errors": {
      "invalid_components": 32,
      "unsupported_features": 18,
      "timeout": 8,
      "others": 12
    }
  }
}
```

---

## Features Priority (Updated with Mobile Export)

### MVP (Minimum Viable Product):
1. ✅ Drag-and-drop component placement
2. ✅ Basic component library (buttons, text, images, containers)
3. ✅ Styling controls (color, size, spacing)
4. ✅ Live canvas preview
5. ✅ Basic export (HTML/CSS)

### Phase 2:
6. Responsive design controls
7. Asset management
8. Component grouping & alignment tools
9. Undo/Redo history
10. Template saving

### Phase 3:
11. Form validation & data binding
12. Interactions (onClick, hover states)
13. Animation & transition editor
14. Collaboration features
15. Advanced export (React, Vue, etc.)

### Phase 3.5 - Website Export (High Priority):
16. **Next.js Export** (server-side rendering, SEO optimized)
17. **React/Vue Export** (SPA with routing and state management)
18. **Static HTML Export** (simplest, zero dependencies)
19. **Shopify Theme Export** (ready to install in Shopify store)
20. **WordPress Theme Export** (ready to install in WordPress)
21. Website component mapping
22. Responsive design optimization
23. SEO metadata generation
24. Deployment to Vercel/Netlify/Shopify/WordPress
25. Website export analytics & monitoring

### Phase 4 - Mobile Export:
26. **iOS Export (SwiftUI/UIKit)**
27. **Android Export (Compose/XML)**
28. **React Native Export (Expo/Bare)**
29. **Flutter Export**
30. Mobile component mapping
31. Platform-specific customization UI
32. App template scaffolding
33. Build script generation
34. Mobile export analytics & monitoring

### Data Structure (Complete CMS Project with Backend):
```json
{
  "project": {
    "id": "proj_123",
    "user_id": "user_abc123",
    "name": "E-Commerce Dashboard",
    "description": "Main store dashboard",
    "status": "active|archived|deleted",
    "created_at": "2024-01-15T10:30:00Z",
    "updated_at": "2024-03-07T15:45:30Z",
    "visibility": "private|team|public",
    "team_id": "team_xyz",
    "collaborators": [
      {
        "user_id": "user_def456",
        "role": "editor",
        "added_at": "2024-02-10T08:00:00Z"
      }
    ],
    "pages": [
      {
        "id": "page_1",
        "name": "Home",
        "slug": "home",
        "components": [...],
        "theme": {...}
      }
    ],
    "analytics": {
      "views": 1523,
      "exports": 34,
      "last_view": "2024-03-07T15:30:00Z"
    }
  }
}
```

---

## Features Priority

### MVP (Minimum Viable Product):
1. ✅ Drag-and-drop component placement
2. ✅ Basic component library (buttons, text, images, containers)
3. ✅ Styling controls (color, size, spacing)
4. ✅ Live canvas preview
5. ✅ Basic export (HTML/CSS)

### Phase 2:
6. Responsive design controls
7. Asset management
8. Component grouping & alignment tools
9. Undo/Redo history
10. Template saving

### Phase 3:
11. Form validation & data binding
12. Interactions (onClick, hover states)
13. Animation & transition editor
14. Collaboration features
15. Advanced export (React, Vue, etc.)

---

## User Stories

### Story 1: Designer Creates a Landing Page
**As a** designer without coding knowledge  
**I want to** drag components onto a canvas and style them visually  
**So that** I can quickly create a responsive landing page without writing CSS

### Story 2: Developer Exports Code
**As a** developer  
**I want to** export the designed layout as clean React code  
**So that** I can integrate it into my project and extend it with logic

### Story 3: Manager Reviews Design
**As a** project manager  
**I want to** view the layout on different devices and test interactions  
**So that** I can approve the design before development

### Story 4: Team Collaborates
**As a** team member  
**I want to** comment on specific sections and track changes  
**So that** we can iterate efficiently without losing feedback

### Story 5: Mobile Developer Exports iOS App
**As a** iOS developer  
**I want to** export the designed layout as production-ready SwiftUI code  
**So that** I can quickly scaffold my app and focus on business logic

### Story 6: Cross-Platform Developer Uses React Native
**As a** cross-platform developer  
**I want to** export a single layout to both iOS and Android with React Native  
**So that** I can maintain one codebase for multiple platforms

### Story 7: Flutter Developer Generates UI Code
**As a** Flutter developer  
**I want to** export the layout with Material 3 design and proper state management  
**So that** I can have a consistent, accessible UI across all platforms

### Story 8: Product Manager Tests Mobile Mockups
**As a** product manager  
**I want to** preview the exported app designs on various devices before development  
**So that** I can verify the design meets requirements before handoff

---

## Success Metrics

- ⏱️ **Time to Layout**: Average time to create a basic layout < 5 minutes
- 🎯 **Adoption**: 80%+ of non-technical team members can use the CMS
- 💾 **Export Quality**: Exported code requires minimal manual adjustments (< 10% of total effort)
- 📱 **Responsiveness**: Layouts work seamlessly across all device sizes
- 😊 **User Satisfaction**: NPS score > 50; ease-of-use rating > 4/5

#### Mobile Export Metrics (Phase 4):
- 📲 **iOS Export Success Rate**: ≥ 97% of exports compile without errors
- 🤖 **Android Export Success Rate**: ≥ 96% of exports build successfully
- ⚡ **Export Generation Time**: iOS < 45s, Android < 50s, React Native < 35s, Flutter < 30s
- 🎯 **Code Quality**: Generated code meets industry standards (linting, formatting)
- 🔄 **Component Mapping Accuracy**: ≥ 95% of components map correctly to native equivalents
- 📊 **Adoption**: 60%+ of mobile developers use mobile export feature
- ✅ **Production Readiness**: 80%+ of exported apps can be submitted to app stores with minimal changes

---

## Design Tone & Aesthetic

**Visual Style**: Modern, clean, professional with intuitive UI patterns  
**Color Scheme**: Light theme with accent colors for interactive elements  
**Typography**: Clear hierarchy with readable sans-serif fonts  
**Interaction**: Smooth animations, immediate visual feedback, forgiving interactions  
**Accessibility**: WCAG 2.1 AA compliance; keyboard navigation support

---

## Example Use Cases

1. **E-Commerce Platform**: Create product pages, checkout flows, admin dashboards
2. **SaaS Applications**: Build onboarding screens, settings pages, data dashboards
3. **Marketing Websites**: Design landing pages, service pages, contact forms
4. **Mobile App Mockups**: Design app screens before development
5. **Internal Tools**: Rapid prototyping of admin panels and business apps
6. **Native iOS Apps**: Export SwiftUI code for App Store applications
7. **Native Android Apps**: Export Jetpack Compose code for Google Play applications
8. **Cross-Platform Apps**: Use React Native or Flutter for code sharing across iOS and Android
9. **Rapid App Prototyping**: Build and test app UIs in days instead of weeks
10. **Design System Implementation**: Create reusable component libraries for large teams

---

## Questions to Consider

- What is the primary user (designer, developer, business user)?
- Should the CMS support version control and branching?
- Do you need a plugin/extension system for custom components?
- Should layouts be framework-agnostic or framework-specific (React, Vue, etc.)?
- What level of interaction complexity is needed (simple clicks vs. complex workflows)?
- Is real-time collaboration a requirement or nice-to-have?
- What file formats should be supported for import/export?

#### Mobile Export Specific Questions:
- Should the platform support native mobile exports (iOS/Android) in Phase 1 or Phase 4?
- Which mobile frameworks are highest priority? (SwiftUI, Compose, React Native, Flutter)
- Should generated code be production-ready or scaffolding/template?
- How much customization should users be able to apply before/after export?
- Should the system support custom native module integration?
- What level of API client generation is needed (REST, GraphQL)?
- Should exported apps include sample navigation and app structure?
- How much platform-specific styling and behavior customization is acceptable?
- Should build scripts and deployment guides be auto-generated?
- What testing framework should be included (XCTest, Espresso, Jest, etc.)?

---

## Deliverables

When implementing this CMS, provide:
1. **Fully functional CMS interface** with drag-and-drop layout builder
2. **Component library** with at least 15-20 pre-built components
3. **Live preview** and responsive design preview
4. **Export functionality** (HTML/CSS or framework-specific code)
5. **User documentation** with tutorials and keyboard shortcuts
6. **Performance optimization** for smooth interactions with complex layouts
7. **Accessibility features** for inclusive design

#### Website Export Deliverables (Phase 3.5):
8. **Next.js Export Engine** with SSR/SSG/hybrid rendering
9. **React/Vue Export Engine** with routing and state management
10. **Static HTML Export Engine** for zero-dependency websites
11. **Shopify Theme Generator** with Liquid templates
12. **WordPress Theme Generator** with PHP templates
13. **Component Mapping Library** with web framework equivalents
14. **Responsive Design Engine** auto-optimized for mobile
15. **SEO Optimization System** (metadata, structured data, sitemaps)
16. **Deployment Integration** (Vercel, Netlify, Shopify, WordPress)
17. **Website Export Configuration UI** with framework-specific options
18. **Performance Optimization** (image optimization, code splitting, compression)
19. **Website Export Documentation** with deployment guides per platform
20. **Example Projects** for Next.js, React, Vue, Shopify, WordPress
21. **Hosting Integration** with automated deployment scripts
22. **Analytics & Monitoring** for website exports

#### Mobile Export Deliverables (Phase 4):
23. **iOS Export Engine** supporting SwiftUI and UIKit generation
24. **Android Export Engine** supporting Jetpack Compose and XML generation
25. **Cross-Platform Generators** for React Native (Expo + Bare) and Flutter
26. **Component Mapping Library** with iOS/Android/RN/Flutter equivalents
27. **Export Configuration UI** with platform-specific options
28. **Code Generation Templates** with best practices for each platform
29. **Build Script Generators** (Xcode, Gradle, npm build configs)
30. **App Scaffolding System** with complete project structure
31. **Export Monitoring Dashboard** with success rates and analytics
32. **Mobile Export Documentation** with integration guides per platform
33. **Example Projects** for iOS, Android, React Native, and Flutter
34. **CI/CD Integration Templates** (GitHub Actions, FastLane, etc.)
35. **Testing Framework Setup** (unit tests, UI tests, integration tests)

---

## Next Steps

1. Clarify the primary user and use case
2. Define component library scope and customization options
3. Decide on technology stack and deployment method
4. Create wireframes and interactive prototypes
5. Build MVP with core features
6. Test with real users and iterate based on feedback
7. Plan roadmap for Phase 2 and Phase 3 features
8. **Plan Phase 4 mobile export**: Decide on platform priorities (iOS first vs. all platforms simultaneous)
9. **Build component mapping library**: Define iOS/Android/RN/Flutter component equivalents
10. **Set up code generation infrastructure**: Template engines, AST parsing, code formatting
11. **Develop export configuration UI**: Allow users to customize export options per platform
12. **Create example projects**: Provide starter templates for each platform
13. **Establish quality metrics**: Set success rates, build time, code coverage targets
14. **Plan CI/CD integration**: GitHub Actions, BuildKit, automated app store submission
15. **Beta test with mobile developers**: Gather feedback on code quality and integration ease
